package com.aogy.rootchecker;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.aogy.rootchecker.databinding.*;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.play.core.integrity.*;
import com.google.android.play.core.integrity.model.*;
import com.google.android.play.integrity.internal.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends AppCompatActivity {
	
	private MainBinding binding;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = MainBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		setSupportActionBar(binding.Toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		binding.Toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		
		binding.textview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		binding.button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				boolean hasSuperUser = false;
				
				try {
					java.lang.Process process = Runtime.getRuntime().exec(new String[]{"su", "-c", "exit"});
					long timeout = 2000;
					long start = System.currentTimeMillis();
					boolean finished = false;
					
					while (System.currentTimeMillis() - start < timeout) {
						try {
							int exitCode = process.exitValue();
							finished = true;
							hasSuperUser = true; 
							break;
						} catch (IllegalThreadStateException e) {
							hasSuperUser = true;
							try { Thread.sleep(100); } catch (InterruptedException ignored) {}
						}
					}
					
					if (!finished) {
						process.destroy();
					}
					
				} catch (Exception e) {
					hasSuperUser = false;
				}
				if (hasSuperUser) {
					binding.textview2.setText("Had SuperUser!");
				} else {
					binding.textview2.setText("Haven't SuperUser Or Hided");
				}
				
			}
		});
		
		binding.button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				boolean isUnlocked = false;
				try {
					Class<?> systemProperties = Class.forName("android.os.SystemProperties");
					java.lang.reflect.Method get = systemProperties.getMethod("get", String.class);
					
					String bootState = (String) get.invoke(null, "ro.boot.verifiedbootstate");
					String flashLocked = (String) get.invoke(null, "ro.boot.flash.locked");
					
					if ("orange".equals(bootState) || "yellow".equals(bootState) || "0".equals(flashLocked)) {
						isUnlocked = true;
					}
				} catch (Exception e) {
					// Skip error
				}
				
				// Step 2: Check Folder Tricky Store (/data/adb/tricky_store)
				java.io.File trickyFolder = new java.io.File("/data/adb/tricky_store");
				if (trickyFolder.exists()) {
					isUnlocked = true;
				}
				
				// Step 3: Check Package Bootloader Spoofing
				String[] spoofPackages = {
					"com.bns.bootloaderspoofer",
					"io.github.chiteroman.playintegrityfix",
					"eg.target.spoof.bootloader"
				};
				
				android.content.pm.PackageManager pm = getPackageManager();
				for (String pkg : spoofPackages) {
					try {
						pm.getPackageInfo(pkg, 0);
						isUnlocked = true;
						break;
					} catch (android.content.pm.PackageManager.NameNotFoundException e) {
						// Continue loop
					}
				}
				
				// Áp dụng kết quả lên TextView (Đã sửa lỗi ambiguous Process và ID textview4)
				TextView txtResult = (TextView) findViewById(R.id.textview4);
				if (isUnlocked) {
					txtResult.setText("Unlocked Bootloader");
				} else {
					txtResult.setText("Locked Bootloader");
				}
				
			}
		});
		
		binding.button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				boolean basicPass = false;
				boolean devicePass = false;
				boolean strongPass = false;
				
				try {
					Class<?> sysProp = Class.forName("android.os.SystemProperties");
					java.lang.reflect.Method get = sysProp.getMethod("get", String.class);
					
					String bootState = (String) get.invoke(null, "ro.boot.verifiedbootstate");
					String buildTags = android.os.Build.TAGS;
					java.io.File lsposed = new java.io.File("/data/adb/lspd");
					java.io.File xposed = new java.io.File("/system/framework/XposedBridge.jar");
					if (!lsposed.exists() && !xposed.exists()) {
						basicPass = true;
					}
					java.io.File trickyFolder = new java.io.File("/data/adb/tricky_store");
					if (basicPass) {
						if ("green".equals(bootState) || trickyFolder.exists()) {
							devicePass = true;
						}
					}
					if (devicePass && "green".equals(bootState) && buildTags != null && buildTags.contains("release-keys")) {
						strongPass = true;
					}
					
				} catch (Exception e) {}
				binding.textview7.setText("Basic_Integrity: " + (basicPass ? "PASS" : "FAIL"));
				binding.textview8.setText("Device_Integrity: " + (devicePass ? "PASS" : "FAIL"));
				binding.textview9.setText("Strong_Integrity: " + (strongPass ? "PASS" : "FAIL"));
				
			}
		});
	}
	
	private void initializeLogic() {
	}
	
}